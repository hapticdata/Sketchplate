var Attr = require("../util").FileAttr;
var x = new Attr("assets/attributes_test/new folder/hidden_readonly.txt");
console.log(x.toString());